import { contextBridge, ipcRenderer } from 'electron'
import { electronAPI } from '@electron-toolkit/preload'

// Custom APIs for renderer
const api = {
  serial: {
    listPorts: () =>
      ipcRenderer.invoke('serial:list-ports'),

    testConnection: (configuration) =>
      ipcRenderer.invoke(
        'serial:test-connection',
        configuration
      ),

    connect: (configuration) =>
      ipcRenderer.invoke(
        'serial:connect',
        configuration
      ),

    disconnect: () =>
      ipcRenderer.invoke('serial:disconnect'),

    getState: () =>
      ipcRenderer.invoke('serial:get-state'),

    onMeasurement: (callback) => {
      const listener = (_event, measurement) => {
        callback(measurement)
      }

      ipcRenderer.on('serial:measurement', listener)

      return () => {
        ipcRenderer.removeListener(
          'serial:measurement',
          listener
        )
      }
    },

    onDisconnected: (callback) => {
      const listener = (_event, data) => {
        callback(data)
      }

      ipcRenderer.on('serial:disconnected', listener)

      return () => {
        ipcRenderer.removeListener(
          'serial:disconnected',
          listener
        )
      }
    },

    onConnectionError: (callback) => {
      const listener = (_event, data) => {
        callback(data)
      }

      ipcRenderer.on(
        'serial:connection-error',
        listener
      )

      return () => {
        ipcRenderer.removeListener(
          'serial:connection-error',
          listener
        )
      }
    }
  }
}

// Use `contextBridge` APIs to expose Electron APIs to
// renderer only if context isolation is enabled, otherwise
// just add to the DOM global.
if (process.contextIsolated) {
  try {
    contextBridge.exposeInMainWorld('electron', electronAPI)
    contextBridge.exposeInMainWorld('api', api)
  } catch (error) {
    console.error(error)
  }
} else {
  // @ts-ignore (define in dts)
  window.electron = electronAPI
  // @ts-ignore (define in dts)
  window.api = api
}
