import type {
  Measurement,
  SerialConfiguration,
  SerialConnectionState,
  SerialPortInfo,
  SerialResult
} from '../renderer/src/types/serial'

export interface SerialApi {
  listPorts: () => Promise<
    SerialResult<SerialPortInfo[]>
  >

  testConnection: (
    configuration: SerialConfiguration
  ) => Promise<
    SerialResult<{
      path: string
      baudRate: number
      firstLine: string
    }>
  >

  connect: (
    configuration: SerialConfiguration
  ) => Promise<
    SerialResult<{
      path: string
      baudRate: number
      alreadyConnected: boolean
    }>
  >

  disconnect: () => Promise<SerialResult>

  getState: () => Promise<
    SerialResult<SerialConnectionState>
  >

  onMeasurement: (
    callback: (measurement: Measurement) => void
  ) => () => void

  onDisconnected: (
    callback: (data: { path: string | null }) => void
  ) => () => void

  onConnectionError: (
    callback: (data: { message: string }) => void
  ) => () => void
}

declare global {
  interface Window {
    api: {
      serial: SerialApi
    }

    electron: unknown
  }
}