import { useParams } from 'react-router-dom'

function ReportDetailPage() {
  const { reportId } = useParams()

  return (
    <section>
      <p className="text-sm font-semibold uppercase tracking-[0.2em] text-violet-700">
        Reportes
      </p>

      <h1 className="mt-2 text-3xl font-bold">
        Detalle del reporte
      </h1>

      <p className="mt-4 text-slate-600">
        Identificador recibido: {reportId}
      </p>
    </section>
  )
}

export default ReportDetailPage