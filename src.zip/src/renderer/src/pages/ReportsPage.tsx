function ReportsPage() {
  return (
    <section>
      <p className="text-sm font-semibold uppercase tracking-[0.2em] text-violet-700">
        Análisis
      </p>

      <h1 className="mt-2 text-3xl font-bold">
        Reportes
      </h1>

      <div className="mt-8 rounded-3xl border border-white/70 bg-white/55 p-10 text-center shadow-lg backdrop-blur-xl">
        <h2 className="text-xl font-semibold">
          No hay datos disponibles
        </h2>

        <p className="mt-2 text-slate-500">
          Finaliza una o más sesiones para generar un reporte.
        </p>
      </div>
    </section>
  )
}

export default ReportsPage