import { useParams } from 'react-router-dom'

function HistoryDetailPage() {
  const { sessionId } = useParams()

  return (
    <section>
      <p className="text-sm font-semibold uppercase tracking-[0.2em] text-emerald-700">
        Historial
      </p>

      <h1 className="mt-2 text-3xl font-bold">
        Detalle de la sesión
      </h1>

      <p className="mt-4 text-slate-600">
        Identificador recibido: {sessionId}
      </p>
    </section>
  )
}

export default HistoryDetailPage