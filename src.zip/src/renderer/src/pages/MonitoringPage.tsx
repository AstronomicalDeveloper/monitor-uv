import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Button from '../components/common/Button'
import GlassCard from '../components/glass/GlassCard'
import GlassPanel from '../components/glass/GlassPanel'

const initialMeasurement = {
  uvAdc: null,
  uvVoltage: null,
  level: null,
  luminosity: null,
  temperature: null,
  humidity: null,
  pressure: null,
  presence: null,
  dateTime: null,
  receivedAt: null
}

function MonitoringPage() {
  const navigate = useNavigate()

  const [measurement, setMeasurement] =
    useState(initialMeasurement)

  const [connected, setConnected] = useState(false)
  const [connectedPort, setConnectedPort] = useState(null)
  const [receivedMeasurements, setReceivedMeasurements] =
    useState(0)

  const [connectionError, setConnectionError] =
    useState('')

  useEffect(() => {
    async function loadConnectionState() {
      try {
        const result = await window.api.serial.getState()

        if (result.success) {
          setConnected(result.data.connected)
          setConnectedPort(result.data.path)
        }
      } catch (error) {
        console.error(
          'No se pudo consultar la conexión:',
          error
        )

        setConnectionError(
          'No se pudo consultar el estado del dispositivo.'
        )
      }
    }

    loadConnectionState()

    const removeMeasurementListener =
      window.api.serial.onMeasurement(
        (newMeasurement) => {
          setMeasurement(newMeasurement)
          setReceivedMeasurements(
            (currentValue) => currentValue + 1
          )
          setConnected(true)
          setConnectionError('')
        }
      )

    const removeDisconnectedListener =
      window.api.serial.onDisconnected(() => {
        setConnected(false)
        setConnectedPort(null)
        setConnectionError(
          'El dispositivo fue desconectado.'
        )
      })

    const removeErrorListener =
      window.api.serial.onConnectionError((data) => {
        setConnectionError(
          data.message ||
            'Ocurrió un error en la conexión serial.'
        )
      })

    return () => {
      removeMeasurementListener()
      removeDisconnectedListener()
      removeErrorListener()
    }
  }, [])

  function formatValue(value, decimals = 2) {
    if (
      value === null ||
      value === undefined ||
      Number.isNaN(value)
    ) {
      return '--'
    }

    return Number(value).toFixed(decimals)
  }

  return (
    <section className="space-y-6">
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-emerald-700">
            Monitoreo
          </p>

          <h1 className="mt-2 text-3xl font-bold text-slate-800">
            Monitoreo en tiempo real
          </h1>

          <p className="mt-2 text-slate-500">
            {connected
              ? `Recibiendo datos desde ${connectedPort ?? 'el prototipo'}.`
              : 'No existe una conexión activa con el prototipo.'}
          </p>
        </div>

        {!connected && (
          <Button onClick={() => navigate('/conexion')}>
            Ir a conexión
          </Button>
        )}
      </header>

      {connectionError && (
        <div className="rounded-2xl border border-rose-200 bg-rose-50/70 p-4 text-rose-700">
          <p className="font-semibold">
            Problema de conexión
          </p>

          <p className="mt-1 text-sm">
            {connectionError}
          </p>
        </div>
      )}

      <GlassPanel>
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span
              className={[
                'h-3 w-3 rounded-full',
                connected
                  ? 'animate-pulse bg-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.7)]'
                  : 'bg-slate-400'
              ].join(' ')}
            />

            <div>
              <p className="font-semibold text-slate-800">
                {connected
                  ? 'Dispositivo conectado'
                  : 'Sin conexión'}
              </p>

              <p className="text-sm text-slate-500">
                {connectedPort ?? 'Puerto no disponible'}
              </p>
            </div>
          </div>

          <div className="text-right">
            <p className="text-sm text-slate-500">
              Mediciones recibidas
            </p>

            <p className="text-2xl font-bold text-violet-700">
              {receivedMeasurements}
            </p>
          </div>
        </div>
      </GlassPanel>

      <section className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
        <GlassCard className="md:col-span-2 xl:col-span-1">
          <p className="text-sm font-semibold uppercase tracking-wider text-violet-700">
            Sensor UV
          </p>

          <div className="mt-4 flex items-end gap-2">
            <p className="font-mono text-5xl font-bold text-slate-800">
              {formatValue(measurement.uvAdc, 0)}
            </p>

            <span className="mb-1 text-sm text-slate-500">
              ADC
            </span>
          </div>

          <div className="mt-5 border-t border-white/70 pt-4">
            <p className="text-sm text-slate-500">
              Voltaje
            </p>

            <p className="mt-1 text-xl font-bold text-slate-700">
              {formatValue(measurement.uvVoltage, 3)} V
            </p>
          </div>

          <div className="mt-4">
            <p className="text-sm text-slate-500">
              Nivel de alerta
            </p>

            <span
              className={[
                'mt-2 inline-flex rounded-full px-3 py-1 text-sm font-semibold',
                measurement.level === 'BAJO'
                  ? 'bg-emerald-100 text-emerald-700'
                  : measurement.level === 'MEDIO'
                    ? 'bg-amber-100 text-amber-700'
                    : measurement.level === 'ALTO'
                      ? 'bg-rose-100 text-rose-700'
                      : 'bg-slate-100 text-slate-500'
              ].join(' ')}
            >
              {measurement.level ?? 'Sin datos'}
            </span>
          </div>
        </GlassCard>

        <GlassCard>
          <p className="text-sm font-semibold text-slate-500">
            Temperatura
          </p>

          <p className="mt-4 font-mono text-4xl font-bold text-slate-800">
            {formatValue(measurement.temperature)} °C
          </p>
        </GlassCard>

        <GlassCard>
          <p className="text-sm font-semibold text-slate-500">
            Humedad
          </p>

          <p className="mt-4 font-mono text-4xl font-bold text-slate-800">
            {formatValue(measurement.humidity)} %
          </p>
        </GlassCard>

        <GlassCard>
          <p className="text-sm font-semibold text-slate-500">
            Presión atmosférica
          </p>

          <p className="mt-4 font-mono text-4xl font-bold text-slate-800">
            {formatValue(measurement.pressure)} hPa
          </p>
        </GlassCard>

        <GlassCard>
          <p className="text-sm font-semibold text-slate-500">
            Luminosidad
          </p>

          <p className="mt-4 font-mono text-4xl font-bold text-slate-800">
            {formatValue(measurement.luminosity)} lux
          </p>
        </GlassCard>

        <GlassCard solid>
          <p className="text-sm font-semibold text-slate-500">
            Fecha y hora del prototipo
          </p>

          <p className="mt-4 text-xl font-bold text-slate-800">
            {measurement.dateTime ?? '--'}
          </p>

          <p className="mt-3 text-sm text-slate-500">
            Último paquete completo recibido
          </p>
        </GlassCard>

        <GlassCard
          solid
          className={
            measurement.presence === true
              ? 'border-emerald-200 bg-emerald-50/80'
              : ''
          }
        >
          <p className="text-sm font-semibold text-slate-500">
            Presencia
          </p>

          <div className="mt-4 flex items-center gap-3">
            <span
              className={[
                'h-4 w-4 rounded-full',
                measurement.presence === true
                  ? 'animate-pulse bg-emerald-500 shadow-[0_0_14px_rgba(16,185,129,0.75)]'
                  : measurement.presence === false
                    ? 'bg-slate-400'
                    : 'bg-slate-300'
              ].join(' ')}
            />

            <p className="text-2xl font-bold text-slate-800">
              {measurement.presence === true
                ? 'Detectada'
                : measurement.presence === false
                  ? 'No detectada'
                  : '--'}
            </p>
          </div>

          <p className="mt-3 text-sm text-slate-500">
            Estado actual del sensor PIR
          </p>
        </GlassCard>
      </section>

      <GlassPanel
        title="Gráfica de índice UV"
        description="La gráfica se incorporará cuando definamos el cálculo del índice UV y la sesión de captura."
      >
        <div className="flex h-72 items-center justify-center rounded-2xl border border-dashed border-violet-300/70 bg-white/30 text-slate-400">
          {connected
            ? 'Recibiendo mediciones reales'
            : 'Esperando conexión'}
        </div>
      </GlassPanel>
    </section>
  )
}

export default MonitoringPage