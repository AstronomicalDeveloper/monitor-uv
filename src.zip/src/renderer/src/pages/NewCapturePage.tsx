function NewCapturePage() {
  return (
    <section>
      <p className="text-sm font-semibold uppercase tracking-[0.2em] text-violet-700">
        Sesiones
      </p>

      <h1 className="mt-2 text-3xl font-bold">
        Nueva captura
      </h1>

      <div className="mt-8 rounded-3xl border border-white/70 bg-white/55 p-10 text-center shadow-lg backdrop-blur-xl">
        <h2 className="text-xl font-semibold">
          No se puede iniciar una captura
        </h2>

        <p className="mt-2 text-slate-500">
          Primero debes conectar el prototipo.
        </p>
      </div>
    </section>
  )
}

export default NewCapturePage