import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState
} from 'react'
import type { ReactNode } from 'react'
import type { Measurement } from '../types/serial'

export interface CaptureSession {
  name: string
  location: string
  description: string
  mode: 'manual' | 'timed'
  durationSeconds: number | null
  storageIntervalSeconds: number
}

interface AppProviderProps {
  children: ReactNode
}

const AppContext = createContext(null)

const initialMeasurement = {
  uvAdc: null,
  uvVoltage: null,
  level: null,
  luminosity: null,
  temperature: null,
  humidity: null,
  pressure: null,
  presence: null,
  dateTime: null,
  receivedAt: null
}

export function AppProvider({ children }) {
  const [connected, setConnected] = useState(false)
  const [connectedPort, setConnectedPort] = useState(null)
  const [connectionError, setConnectionError] = useState('')

  const [measurement, setMeasurement] =
    useState<Measurement>(initialMeasurement)

  const [activeSession, setActiveSession] =
    useState<CaptureSession | null>(null)

  const [receivedMeasurements, setReceivedMeasurements] =
    useState(0)

  const [capturing, setCapturing] = useState(false)

  useEffect(() => {
    async function loadConnectionState() {
      try {
        const result = await window.api.serial.getState()

        if (!result.success) {
          setConnectionError(
            result.message ||
              'No se pudo consultar el estado del dispositivo.'
          )
          return
        }

        setConnected(result.data.connected)
        setConnectedPort(result.data.path)
      } catch (error) {
        console.error(
          'No se pudo consultar la conexión serial:',
          error
        )

        setConnectionError(
          'No fue posible comunicarse con el proceso principal.'
        )
      }
    }

    loadConnectionState()

    const removeMeasurementListener =
      window.api.serial.onMeasurement(
        (newMeasurement) => {
          setMeasurement(newMeasurement)

          setReceivedMeasurements(
            (currentValue) => currentValue + 1
          )

          setConnected(true)
          setConnectionError('')
        }
      )

    const removeDisconnectedListener =
      window.api.serial.onDisconnected(() => {
        setConnected(false)
        setConnectedPort(null)
        setCapturing(false)

        setConnectionError(
          'El dispositivo fue desconectado.'
        )
      })

    const removeConnectionErrorListener =
      window.api.serial.onConnectionError((data) => {
        setConnectionError(
          data.message ||
            'Ocurrió un error en la conexión serial.'
        )
      })

    return () => {
      removeMeasurementListener()
      removeDisconnectedListener()
      removeConnectionErrorListener()
    }
  }, [])

  function registerConnection(path) {
    setConnected(true)
    setConnectedPort(path)
    setConnectionError('')
  }

  async function disconnectDevice() {
    try {
      const result = await window.api.serial.disconnect()

      if (!result.success) {
        setConnectionError(
          result.message ||
            'No se pudo desconectar el dispositivo.'
        )

        return false
      }

      setConnected(false)
      setConnectedPort(null)
      setCapturing(false)
      setActiveSession(null)
      setMeasurement(initialMeasurement)
      setReceivedMeasurements(0)
      setConnectionError('')

      return true
    } catch (error) {
      console.error(
        'Error al desconectar el dispositivo:',
        error
      )

      setConnectionError(
        'No fue posible desconectar el dispositivo.'
      )

      return false
    }
  }

  function startCapture(session: CaptureSession): void {
    setActiveSession(session)
    setCapturing(true)
    setReceivedMeasurements(0)
  }

  function stopCapture() {
    setCapturing(false)
  }

  function clearSession() {
    setActiveSession(null)
    setCapturing(false)
    setReceivedMeasurements(0)
  }

  const value = useMemo(
    () => ({
      connected,
      connectedPort,
      connectionError,
      measurement,
      receivedMeasurements,
      activeSession,
      capturing,
      registerConnection,
      disconnectDevice,
      startCapture,
      stopCapture,
      clearSession
    }),
    [
      connected,
      connectedPort,
      connectionError,
      measurement,
      receivedMeasurements,
      activeSession,
      capturing
    ]
  )

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const context = useContext(AppContext)

  if (!context) {
    throw new Error(
      'useApp debe utilizarse dentro de AppProvider.'
    )
  }

  return context
}